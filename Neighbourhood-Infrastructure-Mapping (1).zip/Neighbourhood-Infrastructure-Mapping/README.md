# Neighbourhood Infrastructure Mapping

A web-based college project for recording, mapping and analysing neighbourhood infrastructure problems.
Built with HTML, CSS, JavaScript, Leaflet.js, Chart.js and browser Local Storage.

## Run in VS Code
1. Open this folder in VS Code (File > Open Folder).
2. Install the "Live Server" extension.
3. Right-click `index.html` > "Open with Live Server".
4. An internet connection is needed for map tiles, Leaflet and Chart.js (loaded from CDNs).

## Pages
Dashboard, Add Survey, Infrastructure Map, All Problems, Reports, plus Problem Details and Edit Problem.

## Notes
- Records are saved in this browser only (Local Storage key `infraProblems`). Other devices will not see them.
- Photos are compressed and stored in Local Storage (small, so it can fill up with many photos).
- The Dashboard has a "Load 5 sample records" button for demos. Sample coordinates are illustrative; use real survey coordinates for your final report.
- Edit `PROJECT` at the top of `js/data.js` to set your title, college/group name and map start position.
- Pick on map: on the survey form, click "Pick on map" then click the exact spot.
- Backup JSON / Import JSON lets group members share records between devices.
- Future scope: shared database, login, cloud hosting.

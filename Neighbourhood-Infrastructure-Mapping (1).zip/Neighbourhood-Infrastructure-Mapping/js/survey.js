// Handles both "Add Survey" and "Edit Problem" (when the URL has ?id=INF-01)
const editId=new URLSearchParams(location.search).get("id");
renderNav(editId?"problems.html":"survey.html");
const form=document.getElementById("form");
let photoData="";
const F=n=>form.elements[n];
F("type").innerHTML=TYPES.map(t=>`<option>${t}</option>`).join("");

const TEMPLATES={
 "Pothole":["Pothole in the road surface, dangerous for two-wheelers, especially at night and after rain.","Clean the hole, fill with asphalt mix and compact it."],
 "Broken Streetlight":["Streetlight not working. The street is dark at night and unsafe.","Check the bulb, wiring and fuse, then replace faulty parts."],
 "Water Leakage":["Water leaking from a pipe joint onto the road, wasting water and damaging the surface.","Repair or replace the damaged pipe joint and restore the road."],
 "Damaged Footpath":["Footpath tiles are broken and uneven. Pedestrians may trip or walk on the road.","Replace broken tiles and level the surface."],
 "Garbage":["Waste piled up in a public place, causing smell and health risk.","Clear the waste, place a covered dustbin and arrange regular collection."],
 "Damaged Road":["Road has cracks and uneven patches that will worsen in the rainy season.","Seal cracks, patch damaged sections and improve drainage."]
};
function fillTemplate(){ const t=TEMPLATES[F("type").value]; F("description").value=t?t[0]:""; F("solution").value=t?t[1]:""; }
F("type").addEventListener("change",()=>{ if(!editId) fillTemplate(); });

// Click-to-place: choose the location by clicking the map
let pickMap,pickMark;
function setPick(lat,lng){
  F("latitude").value=(+lat).toFixed(6); F("longitude").value=(+lng).toFixed(6);
  if(pickMark) pickMark.setLatLng([lat,lng]); else pickMark=L.marker([lat,lng]).addTo(pickMap);
}
document.getElementById("pickBtn").onclick=()=>{
  const box=document.getElementById("pick"), open=box.style.display!=="block";
  box.style.display=open?"block":"none"; if(!open) return;
  if(!pickMap){
    const lat=parseFloat(F("latitude").value), lng=parseFloat(F("longitude").value), ok=validCoords(lat,lng);
    pickMap=L.map("pick").setView(ok?[lat,lng]:PROJECT.center,17);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"&copy; OpenStreetMap contributors"}).addTo(pickMap);
    pickMap.on("click",e=>setPick(e.latlng.lat,e.latlng.lng));
    if(ok) setPick(lat,lng);
  }
  setTimeout(()=>pickMap.invalidateSize(),50);
};
function showPhoto(){ const i=document.getElementById("preview"); if(photoData){i.src=photoData;i.style.display="block";} else i.style.display="none"; }
function resetForm(){
  form.reset(); photoData=""; showPhoto(); F("id").value=nextId();
  F("date").value=new Date().toISOString().slice(0,10); fillTemplate();
  document.getElementById("latErr").textContent=""; document.getElementById("lngErr").textContent="";
}
if(editId){
  const p=getProblem(editId);
  if(!p) form.innerHTML='<p class="empty">Problem not found. <a href="problems.html">Back to All Problems</a></p>';
  else{
    ["id","type","location","date","severity","status","description","solution","latitude","longitude"].forEach(k=>F(k).value=p[k]||"");
    photoData=p.photo||""; showPhoto();
  }
}else resetForm();

// Compress the photo and keep it in Local Storage as a small JPEG
F("photo").addEventListener("change",e=>{
  const f=e.target.files[0]; if(!f) return;
  const img=new Image(), r=new FileReader();
  r.onload=()=>{ img.onload=()=>{
    const s=Math.min(1,640/Math.max(img.width,img.height)), c=document.createElement("canvas");
    c.width=img.width*s; c.height=img.height*s; c.getContext("2d").drawImage(img,0,0,c.width,c.height);
    photoData=c.toDataURL("image/jpeg",.6); showPhoto(); }; img.src=r.result; };
  r.readAsDataURL(f);
});
document.getElementById("gps").onclick=()=>{
  if(!navigator.geolocation) return alert("GPS is not available in this browser.");
  navigator.geolocation.getCurrentPosition(pos=>{
    F("latitude").value=pos.coords.latitude.toFixed(6); F("longitude").value=pos.coords.longitude.toFixed(6); if(pickMap){setPick(pos.coords.latitude,pos.coords.longitude);pickMap.setView([pos.coords.latitude,pos.coords.longitude],17);}
  },()=>alert("Could not get your location. Allow location access or enter coordinates manually."));
};
document.getElementById("clear").onclick=()=>{ if(confirm("Clear the form? Unsaved information will be lost.")) editId?location.reload():resetForm(); };

form.addEventListener("submit",e=>{
  e.preventDefault();
  const lat=F("latitude").value.trim(), lng=F("longitude").value.trim();
  document.getElementById("latErr").textContent=""; document.getElementById("lngErr").textContent="";
  if((lat||lng) && !validCoords(lat,lng)){
    document.getElementById("latErr").textContent="Latitude must be between -90 and 90.";
    document.getElementById("lngErr").textContent="Longitude must be between -180 and 180. Enter both values.";
    return;
  }
  const rec={}; ["id","type","location","date","severity","status","description","solution"].forEach(k=>rec[k]=F(k).value.trim());
  rec.latitude=lat; rec.longitude=lng; rec.photo=photoData;
  const list=getProblems();
  try{
    if(editId){ const i=list.findIndex(p=>p.id===editId); list[i]=rec; saveProblems(list); location.href="problem-details.html?id="+encodeURIComponent(editId); return; }
    rec.id=nextId(); list.push(rec); saveProblems(list);
  }catch(err){ return alert("Storage is full. Use a smaller photo or delete old records."); }
  const m=document.getElementById("msg"); m.style.display="block"; m.textContent=`Saved ${rec.id} (${rec.type}, ${rec.location}). Enter the next problem.`;
  resetForm(); window.scrollTo(0,0);
});

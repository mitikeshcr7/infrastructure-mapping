renderNav("reports.html");
const L=getProblems(), by=count(L,"type"), n=s=>L.filter(p=>p.status===s).length;
const top=Object.entries(by).sort((a,b)=>b[1]-a[1])[0];
document.getElementById("cards").innerHTML=[["Total problems",L.length,"b"],["High severity",L.filter(p=>p.severity==="High").length,"r"],["Pending",n("Pending"),""],["In progress",n("In Progress"),"b"],["Resolved",n("Resolved"),"g"]]
 .map(c=>`<div class="card stat ${c[2]}"><b>${c[1]}</b><span>${c[0]}</span></div>`).join("");
document.getElementById("insight").textContent=top?`Most frequent category: ${top[0]} (${top[1]} of ${L.length} problems, ${Math.round(top[1]/L.length*100)}%). ${n("Resolved")} resolved, ${n("Pending")} still pending.`:"No data yet. Add survey records to see the analysis.";
makeCharts(L);
document.getElementById("rows").innerHTML=TYPES.map(t=>{const g=L.filter(p=>p.type===t);return `<tr><td>${t}</td><td>${g.length}</td><td>${g.filter(p=>p.severity==="High").length}</td><td>${g.filter(p=>p.status==="Pending").length}</td><td>${g.filter(p=>p.status==="Resolved").length}</td></tr>`}).join("");

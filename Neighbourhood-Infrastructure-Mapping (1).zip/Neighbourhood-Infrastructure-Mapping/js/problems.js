renderNav("problems.html");
const $=id=>document.getElementById(id);
const opts=(a,l)=>`<option value="">${l}</option>`+a.map(t=>`<option>${t}</option>`).join("");
$("fType").innerHTML=opts(TYPES,"All types"); $("fSev").innerHTML=opts(SEVERITIES,"All severities"); $("fSta").innerHTML=opts(STATUSES,"All statuses");
function draw(){
  const q=$("q").value.toLowerCase(), all=getProblems();
  const L=all.filter(p=>(!q||[p.id,p.type,p.location].some(v=>String(v).toLowerCase().includes(q)))&&(!$("fType").value||p.type===$("fType").value)&&(!$("fSev").value||p.severity===$("fSev").value)&&(!$("fSta").value||p.status===$("fSta").value));
  const rank={High:3,Medium:2,Low:1}, num=p=>parseInt(String(p.id).replace(/\D/g,""),10)||0;
  L.sort((a,b)=>$("sort").value==="old"?num(a)-num(b):$("sort").value==="sev"?(rank[b.severity]-rank[a.severity])||(num(b)-num(a)):num(b)-num(a));
  $("count").textContent=`Showing ${L.length} of ${all.length} problems`;
  $("rows").innerHTML=L.length?L.map(p=>{const i=encodeURIComponent(p.id);return `<tr><td>${esc(p.id)}</td><td>${esc(p.type)}</td><td>${esc(p.location)}</td><td>${tag(p.severity)}</td><td>${tag(p.status)}</td>
   <td><a class="btn sm out" href="problem-details.html?id=${i}">View</a> <a class="btn sm y" href="edit-problem.html?id=${i}">Edit</a> <button class="sm btn del" data-id="${esc(p.id)}">Delete</button></td></tr>`}).join(""):`<tr><td colspan="6" class="empty">No problems match. Clear the filters or add a survey record.</td></tr>`;
}
["q","fType","fSev","fSta","sort"].forEach(i=>$(i).addEventListener("input",draw));
$("clr").onclick=()=>{["q","fType","fSev","fSta"].forEach(i=>$(i).value="");draw();};
$("rows").onclick=e=>{ const id=e.target.dataset.id; if(id&&confirm(`Delete ${id}? This cannot be undone.`)){saveProblems(getProblems().filter(p=>p.id!==id));draw();} };
draw();

function download(name,text,type){ const a=document.createElement("a"); a.href=URL.createObjectURL(new Blob([text],{type})); a.download=name; a.click(); }
$("csv").onclick=()=>{
  const cols=["id","type","location","date","severity","status","description","solution","latitude","longitude"];
  const q=v=>'"'+String(v==null?"":v).replace(/"/g,'""')+'"';
  download("infrastructure-problems.csv",[cols.join(",")].concat(getProblems().map(p=>cols.map(c=>q(p[c])).join(","))).join("\n"),"text/csv");
};
$("json").onclick=()=>download("infrastructure-backup.json",JSON.stringify(getProblems(),null,2),"application/json");
$("imp").onclick=()=>$("impf").click();
$("impf").onchange=e=>{
  const f=e.target.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      const data=JSON.parse(r.result); if(!Array.isArray(data)) throw 0;
      const cur=getProblems(), ids=new Set(cur.map(p=>p.id)); let added=0;
      data.forEach(p=>{ if(p&&p.id&&p.type&&!ids.has(p.id)){ cur.push(p); ids.add(p.id); added++; } });
      saveProblems(cur); draw(); alert(`Imported ${added} new record(s). Records with an existing ID were skipped.`);
    }catch(err){ alert("This file is not a valid backup. Choose a JSON file made with Backup JSON."); }
    e.target.value="";
  };
  r.readAsText(f);
};

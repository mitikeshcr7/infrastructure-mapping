// Central data management: every page reads/writes through these functions.
// ---- EDIT THESE: project name, group and starting map position ----
const PROJECT = {
  title: "Neighbourhood Infrastructure Mapping",
  sub: "Your college name - Group 1",
  center: [16.705, 73.687]   // latitude, longitude of your survey area
};
const KEY = "infraProblems";
const TYPES = ["Pothole","Broken Streetlight","Water Leakage","Damaged Footpath","Garbage","Damaged Road","Other"];
const SEVERITIES = ["Low","Medium","High"];
const STATUSES = ["Pending","In Progress","Resolved"];
const SEV_COLOR = {High:"#c62828",Medium:"#ef8a00",Low:"#2e8b57"};

function getProblems(){ try{ return JSON.parse(localStorage.getItem(KEY))||[]; }catch(e){ return []; } }
function saveProblems(list){ localStorage.setItem(KEY, JSON.stringify(list)); }
function getProblem(id){ return getProblems().find(p=>p.id===id); }
function nextId(){
  const n = getProblems().map(p=>parseInt(p.id.replace(/\D/g,""),10)||0);
  return "INF-" + String((n.length?Math.max(...n):0)+1).padStart(2,"0");
}
function esc(s){ return String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function tag(v){ return `<span class="tag ${esc(v).replace(/ /g,"-")}">${esc(v)}</span>`; }
function count(list,key){ const o={}; list.forEach(p=>o[p[key]]=(o[p[key]]||0)+1); return o; }
function validCoords(lat,lng){
  if(lat===""||lng===""||lat==null||lng==null) return false;
  const a=parseFloat(lat), b=parseFloat(lng);
  return !isNaN(a)&&!isNaN(b)&&a>=-90&&a<=90&&b>=-180&&b<=180;
}
function loadSampleData(){
  const s=(id,type,location,severity,status,lat,lng,d)=>({id,type,location,date:new Date().toISOString().slice(0,10),severity,status,description:d,solution:"Repair or replace as needed",latitude:lat,longitude:lng,photo:""});
  saveProblems([
    s("INF-01","Pothole","Main Road","High","Pending","16.7050","73.6870","Large pothole in the middle of the road"),
    s("INF-02","Broken Streetlight","Market Road","Medium","In Progress","16.7062","73.6891","Streetlight not working at night"),
    s("INF-03","Water Leakage","Station Road","High","Pending","16.7035","73.6852","Pipe leaking near the junction"),
    s("INF-04","Damaged Footpath","College Road","Medium","Resolved","16.7071","73.6840","Broken tiles on the footpath"),
    s("INF-05","Garbage","Temple Lane","Low","Pending","16.7044","73.6903","Waste piled up beside the road")]);
}
// Sidebar navigation shared by all pages
function renderNav(active){
  const pages=[["dashboard.html","Dashboard"],["survey.html","Add Survey"],["map.html","Infrastructure Map"],["problems.html","All Problems"],["reports.html","Reports"]];
  document.getElementById("nav").innerHTML=`<nav class="side"><div class="brand">${esc(PROJECT.title)}<small>${esc(PROJECT.sub)}</small></div>`+
   pages.map(p=>`<a href="${p[0]}" class="${p[0]===active?"on":""}">${p[1]}</a>`).join("")+`</nav>`;
}
function mapsLink(p){ return `https://www.google.com/maps?q=${p.latitude},${p.longitude}`; }

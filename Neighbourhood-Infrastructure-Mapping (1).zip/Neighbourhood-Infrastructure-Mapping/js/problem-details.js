renderNav("problems.html");
const id=new URLSearchParams(location.search).get("id"), p=getProblem(id), box=document.getElementById("box");
if(!p) box.innerHTML='<p class="empty">Problem not found. <a href="problems.html">Back to All Problems</a></p>';
else{
  const hasC=validCoords(p.latitude,p.longitude);
  document.getElementById("title").textContent=`${p.id} - ${p.type}`;
  box.innerHTML=`<dl class="dl"><dt>Location</dt><dd>${esc(p.location)}</dd><dt>Survey date</dt><dd>${esc(p.date)}</dd>
  <dt>Severity</dt><dd>${tag(p.severity)}</dd><dt>Status</dt><dd>${tag(p.status)}</dd>
  <dt>Description</dt><dd>${esc(p.description)||"-"}</dd><dt>Suggested solution</dt><dd>${esc(p.solution)||"-"}</dd>
  <dt>Coordinates</dt><dd>${hasC?`${esc(p.latitude)}, ${esc(p.longitude)} - <a target="_blank" rel="noopener" href="${mapsLink(p)}">Open in Google Maps</a>`:"Not recorded"}</dd>
  ${p.photo?`<dt>Photo</dt><dd><img class="photo" src="${p.photo}" alt="Photo of ${esc(p.type)}"></dd>`:""}</dl>
  <p class="noprint"><a class="btn y" href="edit-problem.html?id=${encodeURIComponent(p.id)}">Edit problem</a> <a class="btn out" href="problems.html">Back to list</a></p>`;
}

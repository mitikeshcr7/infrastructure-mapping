renderNav("map.html");
const map=L.map("map").setView(PROJECT.center,15);
L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"&copy; OpenStreetMap contributors"}).addTo(map);
const layer=L.layerGroup().addTo(map);
const sel=document.getElementById("filter");
sel.innerHTML='<option value="">All categories</option>'+TYPES.map(t=>`<option>${t}</option>`).join("");
function draw(){
  layer.clearLayers();
  const all=getProblems(), f=all.filter(p=>!sel.value||p.type===sel.value), shown=f.filter(p=>validCoords(p.latitude,p.longitude)), pts=[];
  shown.forEach(p=>{
    const ll=[+p.latitude,+p.longitude]; pts.push(ll);
    L.circleMarker(ll,{radius:10,color:"#fff",weight:2,fillColor:SEV_COLOR[p.severity]||"#555",fillOpacity:1}).addTo(layer)
     .bindTooltip(p.id,{permanent:true,direction:"top",offset:[0,-8],className:"lbl"})
     .bindPopup(`<b>${esc(p.id)} - ${esc(p.type)}</b><br>${esc(p.location)}<br>Severity: ${esc(p.severity)} | Status: ${esc(p.status)}<br><a href="problem-details.html?id=${encodeURIComponent(p.id)}">View details</a> | <a target="_blank" rel="noopener" href="${mapsLink(p)}">Open in Google Maps</a>`);
  });
  if(pts.length) map.fitBounds(pts,{padding:[40,40],maxZoom:17});
  document.getElementById("s1").textContent=shown.length;
  document.getElementById("s2").textContent=shown.filter(p=>p.severity==="High").length;
  document.getElementById("s3").textContent=shown.filter(p=>p.status==="Pending").length;
  document.getElementById("note").textContent=f.length>shown.length?`${f.length-shown.length} record(s) have no valid coordinates and are not shown on the map.`:"";
}
sel.onchange=draw; draw();

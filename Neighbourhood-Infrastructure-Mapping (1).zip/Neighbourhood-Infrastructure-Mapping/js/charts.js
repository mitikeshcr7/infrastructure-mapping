// Shared chart builder used by Dashboard and Reports
const _charts={};
function chart(id,type,counts,colors){
  if(_charts[id]) _charts[id].destroy();
  const labels=Object.keys(counts);
  _charts[id]=new Chart(document.getElementById(id),{type,
    data:{labels,datasets:[{data:labels.map(k=>counts[k]),backgroundColor:colors||["#2563a8","#c62828","#ef8a00","#2e8b57","#6b7785","#f2b705","#8e5ea2"],borderWidth:1}]},
    options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:type!=="bar",position:"bottom"}},scales:type==="bar"?{y:{beginAtZero:true,ticks:{precision:0}}}:{}}});
}
function makeCharts(L){
  chart("cCat","doughnut",count(L,"type"));
  const sv=count(L,"severity"), o1={}; SEVERITIES.forEach(s=>o1[s]=sv[s]||0);
  chart("cSev","bar",o1,SEVERITIES.map(s=>SEV_COLOR[s]));
  const st=count(L,"status"), o2={}; STATUSES.forEach(s=>o2[s]=st[s]||0);
  chart("cSta","doughnut",o2,["#6b7785","#2563a8","#2e8b57"]);
}

renderNav("dashboard.html");
function draw(){
  const L=getProblems(), by=count(L,"type");
  document.getElementById("cards").innerHTML=[
    ["Total problems",L.length,"b"],["Potholes",by["Pothole"]||0,"r"],["Broken streetlights",by["Broken Streetlight"]||0,"o"],["Water leakage",by["Water Leakage"]||0,"b"],
    ["Pending",L.filter(p=>p.status==="Pending").length,""],["Resolved",L.filter(p=>p.status==="Resolved").length,"g"]
  ].map(c=>`<div class="card stat ${c[2]}"><b>${c[1]}</b><span>${c[0]}</span></div>`).join("");
  makeCharts(L);
  const recent=[...L].reverse().slice(0,5);
  document.getElementById("recent").innerHTML=recent.length?recent.map(p=>`<tr><td><a href="problem-details.html?id=${encodeURIComponent(p.id)}">${esc(p.id)}</a></td><td>${esc(p.type)}</td><td>${esc(p.location)}</td><td>${tag(p.severity)}</td><td>${tag(p.status)}</td></tr>`).join(""):`<tr><td colspan="5" class="empty">No problems recorded yet. <a href="survey.html">Add your first survey record.</a></td></tr>`;
}
draw();
document.getElementById("sample").onclick=()=>{ if(!getProblems().length||confirm("This replaces all current records with 5 sample records. Continue?")){loadSampleData();draw();} };
document.getElementById("wipe").onclick=()=>{ if(confirm("Delete ALL records? This cannot be undone.")){saveProblems([]);draw();} };
